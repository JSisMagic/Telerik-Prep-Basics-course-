// Solution for Task 3: Powerful pets
/**
    @param {Array<{ name: string, pets: Array<{ name: string, power: number }> }>} players
    */
    export default function powerfulPets(players) {
      // your code starts here
      return Object.values(
      players.reduce((acc, player) => {
      player.pets.reduce((petAcc, pet) => {
      const petObject = petAcc[pet.name] || {
      name: pet.name,
      totalPower: 0,
      mostPowerfulPlayer: player,
      };
      petObject.totalPower += pet.power;
      if (petObject.mostPowerfulPlayer.pets.filter(p => p.name === pet.name).map(p => p.power).reduce((a, b) => Math.max(a, b), 0) < pet.power) {
      petObject.mostPowerfulPlayer = player;
      }
      petAcc[pet.name] = petObject;
      return petAcc;
      }, acc);
      return acc;
      }, {})
      
      ).sort((a, b) => a.name > b.name ? 1 : -1);
      // your code ends here
      }