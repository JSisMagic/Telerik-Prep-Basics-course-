// Solution for Task 2: People with cities and population
/**
 * 
 * @param {{cities: Array<{ id: number, name: string }>, people: Array<{ name: string, city: number }>}} data 
 */
 export default function (data) {
  // your code starts here

  const cityPopulations = data.people.reduce((acc, person) => {
    acc[person.city] = (acc[person.city] || 0) + 1;
    return acc;
  }, {});

  const result = data.people.map(person => {
    const city = data.cities.find(city => city.id === person.city);
    return {
      name: person.name,
      city: {
        name: city.name,
        population: cityPopulations[person.city],
      },
    };
  });

  // your code ends here
  return result;
}
