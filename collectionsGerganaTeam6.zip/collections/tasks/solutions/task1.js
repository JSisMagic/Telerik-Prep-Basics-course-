// Solution for Task 1: Usable properties

export default function (data) {
  // your code starts here
  return data.map(item => {
    return item.usable.reduce((newObj, prop) => {
      if (item.hasOwnProperty(prop)) {
        newObj[prop] = item[prop];
      }
      return newObj;
    }, {});
  });
  // your code ends here
};
