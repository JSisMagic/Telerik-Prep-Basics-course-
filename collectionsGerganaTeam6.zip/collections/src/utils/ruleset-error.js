export class RulesetError extends Error { }
